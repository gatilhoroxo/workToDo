package quest1;
public enum Ticket {
    ADULT,CHILD;
}
