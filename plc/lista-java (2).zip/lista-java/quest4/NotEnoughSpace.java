public class NotEnoughSpace extends Exception {
    
    public NotEnoughSpace() {
        super("Nao ha espaco suficiente para adicionar o item");
    }
}
