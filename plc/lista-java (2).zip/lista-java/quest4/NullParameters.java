public class NullParameters extends Exception {

    public NullParameters() {
        super("Parametros nulos nao sao permitidos");
    }

}
