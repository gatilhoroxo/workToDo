public class NotFound extends Exception {

    public NotFound() {
        super("Item nao encontrado");
    }

}
