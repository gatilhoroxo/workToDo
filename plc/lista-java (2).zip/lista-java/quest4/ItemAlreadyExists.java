public class ItemAlreadyExists extends Exception {

    public ItemAlreadyExists() {
        super("Item ja existe");
    }

}
