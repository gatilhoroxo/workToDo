package quest2;

public class ClienteVip extends Cliente {
    public ClienteVip(String nome, int mes){
        super(nome, mes);
    }
}
