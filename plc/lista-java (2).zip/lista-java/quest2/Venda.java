package quest2;
import java.util.ArrayList;

public class Venda {
    private ArrayList<Integer> produtos;
    private double valor;
    private int cliente;
    
    public Venda(Menu menu, int[] compra, int cliente){
        
    }
}
