package quest2;

public class ClienteNormal extends Cliente {
    public ClienteNormal(String nome, int mes){
        super(nome, mes);
    }
}
