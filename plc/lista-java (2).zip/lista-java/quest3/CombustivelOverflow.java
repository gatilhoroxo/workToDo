package quest3;

public class CombustivelOverflow extends Exception{
    public CombustivelOverflow(){
        super("Tanque ja esta cheio demais!");
    }
}
