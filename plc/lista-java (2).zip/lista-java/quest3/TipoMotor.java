package quest3;

public enum TipoMotor {
    GASOLINA, ETANOL, FLEX
}
