package quest3;

public class CombustivelNaoCompativel extends Exception {
    public CombustivelNaoCompativel(){
        super("Combustivel imcompativel com o motor desse automovel!");
    }
}
